from flask import Flask, render_template,request, jsonify, session, redirect, url_for, send_file
from hosting_bd import Administrador, PlanHosting, Descuento, Cliente, ContratoHosting, Comentario
from flask_socketio import SocketIO, send
import json
import os

app = Flask(__name__)
app.secret_key = "llave secreta"
socketio = SocketIO(app)
connected_users = set()

def num_visitas():
    if os.path.exists('visitas.json'):
        with open('visitas.json', 'r') as f:
            visitas_data = json.load(f)
    else:
        visitas_data = {'visitas': 0}

    return visitas_data['visitas']

@app.route('/')
def main():
    planes = PlanHosting.listar()
    for plan in planes:
        descuento = Descuento.leer_por_plan(plan['id'])
        if descuento:
            plan['descuento'] = descuento['descuento']
        else:
            plan['descuento'] = 0
    return render_template('index.html', conectados = len(connected_users)+1, visitas=num_visitas(), planes=planes)

@app.route('/Clientes')
def clientes():
    clientes = Cliente.listar()
    return render_template('clientes.html', conectados = len(connected_users)+1, visitas=num_visitas(), clientes=clientes)

@app.route('/preguntas')
def preguntas():
    return render_template('preguntas.html', conectados = len(connected_users)+1, visitas=num_visitas())

@app.route('/chatbot')
def chatbot():
    return render_template('chatbot.html', conectados = len(connected_users)+1, visitas=num_visitas())

@app.route('/mensaje', methods=['post'])
def mensaje():
    nombre = request.form.get('nombre')
    correo = request.form.get('correo')
    mensaje = request.form.get('mensaje')
    Comentario.crear(nombre, correo, mensaje)
    return redirect(url_for('main'))

@app.route('/loginPage')
def login_page():
    if not 'admin' in session:
        return render_template('login.html')
    if session['admin']:
        return redirect(url_for('admin'))
    else:
        return render_template('login.html')

@app.route('/login', methods=['get', 'post'])
def login():
    if request.method=='POST':
        usuario = request.form.get('usuario')
        password = request.form.get('password')
        admin = Administrador.leer_por_id(usuario)
        if admin:
            if admin['contraseña'] == password:
                session['admin'] = True
                return redirect(url_for('admin'))
            else:
                return render_template('login.html', mensaje='usuario y/o contraseña incorrectos')
        else:
            return render_template('login.html', mensaje='usuario y/o contraseña incorrectos')
        
    return render_template('login.html', mensaje='')

@app.route('/logout')
def logout():
    session['admin'] = False
    return redirect(url_for('main'))

@app.route('/admin')
def admin():
    if not session['admin']:
        return redirect(url_for('main'))
    return render_template('admin.html', conectados = len(connected_users)+1, visitas=num_visitas(), admin=True)

@app.route('/comentarios')
def comentarios():
    if not session['admin']:
        return redirect(url_for('main'))
    page = request.args.get('page', 1, type=int)
    limit = 10
    offset = (page - 1) * limit
    
    comentarios = Comentario.listar(offset, limit)
    total_comentarios = Comentario.cantidad()

    total_paginas = (total_comentarios // limit) + (1 if total_comentarios % limit > 0 else 0)

    return render_template('comentarios.html', conectados = len(connected_users)+1, visitas=num_visitas(), admin=True,
                           comentarios=comentarios, 
                           total_comentarios=total_comentarios,
                           total_paginas=total_paginas, 
                           current_page=page)

@app.route('/catalogos')
def catalogos():
    if not session['admin']:
        return redirect(url_for('main'))
    return render_template('catalogo.html', conectados = len(connected_users)+1, visitas=num_visitas(), admin=True)

@app.route('/dashboard/<int:municipio_id>')
def dashboard(municipio_id = 0):    

    return render_template('dashboard.html')

@socketio.on('connect')
def on_connect():
    if request.sid in connected_users:
        return
    connected_users.add(request.sid)
    update_visitas()

    print(f"Usuario conectado. Usuarios activos: {len(connected_users)}")

@socketio.on('disconnect')
def on_disconnect():

    if request.sid in connected_users:
        connected_users.remove(request.sid)
        update_visitas()

    print(f"Usuario desconectado. Usuarios activos: {len(connected_users)}")

def update_visitas():
    visitas = num_visitas()
    visitas_data = {'visitas': visitas+1}
    with open('visitas.json', 'w') as f:
        json.dump(visitas_data, f)

if __name__ == '__main__':
    socketio.run(app, debug=True)
    app.run(debug=True, host="0.0.0.0")