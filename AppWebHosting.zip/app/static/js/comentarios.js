const comentariosLista = document.querySelector('.comentarios-lista');
comentariosLista.style.opacity = 0;

setTimeout(() => {
    comentariosLista.style.transition = 'opacity 0.5s';
    comentariosLista.style.opacity = 1;
}, 100);