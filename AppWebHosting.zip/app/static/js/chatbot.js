/*const botui = new BotUI('chatbot');

botui.message.add({
    content: '¡Hola! Soy tu chatbot. ¿Cómo puedo ayudarte hoy?'
}).then(function() {
    return botui.action.text({
        action: {
            placeholder: 'Escribe tu pregunta...'
        }
    });
}).then(function(res) {
    botui.message.add({
        content: '¡Interesante! Estás preguntando sobre: ' + res.value
    }).then(function() {
        return botui.message.add({
            content: 'Te puedo ayudar con algunas cosas básicas, ¿quieres saber más?'
        });
    }).then(function() {
        return botui.action.button({
            action: [
                { text: 'Sí', value: 'yes' },
                { text: 'No', value: 'no' }
            ]
        });
    }).then(function(res) {
        if (res.value === 'yes') {
            botui.message.add({
                content: '¡Genial! ¿Sobre qué te gustaría aprender más?'
            });
        } else {
            botui.message.add({
                content: '¡Está bien! Si necesitas ayuda más tarde, solo pregúntame. 😊'
            });
        }
    });
});*/

const botui = new BotUI('chatbot');

botui.message.add({
    content: '¡Hola! Soy tu chatbot. ¿Cómo puedo ayudarte hoy?'
}).then(initChat);

function initChat() {
    botui.action.text({
        action: {
            placeholder: 'Escribe tu pregunta...'
        }
    }).then(function(res) {
        handleQuestion(res.value.toLowerCase());
    });
}

function handleQuestion(question) {
    if (question.includes('hosting')) {
        if (question.includes('que es') || question.includes('significa')) {
            botui.message.add({
                content: 'Un servicio de hosting es un espacio en un servidor donde puedes almacenar tu sitio web o aplicación para que sea accesible en internet.'
            }).then(askIfMoreQuestions);
        } else if (question.includes('tipos')) {
            botui.message.add({
                content: 'Existen varios tipos de hosting: compartido, VPS, dedicado y en la nube. Cada uno tiene diferentes costos, capacidades y niveles de control.'
            }).then(askIfMoreQuestions);
        } else {
            botui.message.add({
                content: '¿Te interesa saber qué es un hosting o los tipos de hosting disponibles?'
            }).then(askIfMoreQuestions);
        }
    } else if (question.includes('poliza') || question.includes('garantía')) {
        botui.message.add({
            content: 'Una póliza de garantía asegura la reparación o reemplazo de un producto o servicio si tiene defectos, según los términos establecidos.'
        }).then(askIfMoreQuestions);
    } else if (question.includes('dominio')) {
        botui.message.add({
            content: 'Un dominio es la dirección que usan las personas para acceder a tu sitio web, como www.ejemplo.com. Es como la dirección de tu casa en internet.'
        }).then(askIfMoreQuestions);
    } else if (question.includes('servidor')) {
        botui.message.add({
            content: 'Un servidor es una computadora potente que almacena datos y los distribuye a otros dispositivos a través de internet o una red local.'
        }).then(askIfMoreQuestions);
    } else {
        botui.message.add({
            content: 'No estoy seguro de entender tu pregunta. Por ahora puedo ayudarte con temas como hosting, pólizas de garantía, dominios y servidores. 😊'
        }).then(askIfMoreQuestions);
    }
}

function askIfMoreQuestions() {
    botui.message.add({
        content: '¿Necesitas que responda otra pregunta?'
    }).then(function() {
        return botui.action.button({
            action: [
                { text: 'Sí', value: 'yes' },
                { text: 'No', value: 'no' }
            ]
        });
    }).then(function(res) {
        if (res.value === 'yes') {
            initChat();
        } else {
            botui.message.add({
                content: '¡Gracias por usar el chatbot! Si necesitas ayuda más tarde, estaré aquí. 😊'
            });
        }
    });
}
