const slides = document.querySelectorAll('.slide');
const dots = document.querySelectorAll('.dot');
let currentIndex = 0;

function goToSlide(index) {
    const slideshow = document.querySelector('.slideshow');
    slideshow.style.transform = `translateY(-${index * 300}px)`;
    dots.forEach(dot => dot.classList.remove('active'));
    dots[index].classList.add('active');
    currentIndex = index;
}

dots.forEach(dot => {
    dot.addEventListener('click', () => {
        goToSlide(dot.dataset.index);
    });
});

goToSlide(currentIndex);


const socket = io.connect('http://192.168.254.116:5000/');
socket.on('connect', function() {
    console.log('Conexión establecida con el servidor');
});