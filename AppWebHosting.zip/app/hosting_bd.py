from sqlalchemy import create_engine, Column, Integer, String, Date, Text, Boolean, ForeignKey, DECIMAL, TIMESTAMP, func, text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, sessionmaker
from datetime import date, datetime, timedelta

Base = declarative_base()

DATABASE_URL = "mysql+pymysql://root:AbigailDiaz19/@localhost/hosting"
engine = create_engine(DATABASE_URL)
Session = sessionmaker(bind=engine)
session = Session()

class Administrador(Base):
    __tablename__ = 'Administrador'

    usuario = Column(String(30), primary_key=True)
    contraseña = Column(String(30), nullable=False)

    def to_dict(self):
        return {
            "usuario": self.usuario,
            "contraseña": self.contraseña
        }
#MVC
    @classmethod
    def crear(cls, usuario, contraseña):
        nuevo_administrador = Administrador(usuario=usuario, contraseña=contraseña)
        session.add(nuevo_administrador)
        session.commit()
        return nuevo_administrador

    @classmethod
    def leer_por_id(cls, usuario):
        admin = session.query(cls).filter_by(usuario=usuario).first()
        if admin:
            return admin.to_dict()
        return None

    @classmethod
    def modificar(cls, usuario, nueva_contraseña):
        admin = session.query(cls).filter_by(usuario=usuario).first()
        if admin:
            admin.contraseña = nueva_contraseña
            session.commit()

    @classmethod
    def eliminar(cls, usuario):
        admin = session.query(cls).filter_by(usuario=usuario).first()
        if admin:
            session.delete(admin)
            session.commit()

class PlanHosting(Base):
    __tablename__ = 'PlanHosting'

    id = Column(Integer, primary_key=True, autoincrement=True)
    nombre = Column(String(100), nullable=False)
    descripcion = Column(Text, nullable=True)
    precio = Column(DECIMAL(10, 2), nullable=False)

    descuentos = relationship("Descuento", back_populates="plan_hosting")

    def to_dict(self):
        return {
            "id": self.id,
            "nombre": self.nombre,
            "descripcion": self.descripcion,
            "precio": float(self.precio),
        }

    @classmethod
    def crear(cls, nombre, descripcion, precio):
        nuevo_plan = cls(nombre=nombre, descripcion=descripcion, precio=precio)
        session.add(nuevo_plan)
        session.commit()
        return nuevo_plan

    @classmethod
    def leer_por_id(cls, id):
        plan = session.query(cls).filter_by(id=id).first()
        if plan:
            return plan.to_dict()
        return None

    @classmethod
    def modificar(cls, id, nuevo_nombre, nueva_descripcion, nuevo_precio):
        plan = session.query(cls).filter_by(id=id).first()
        if plan:
            plan.nombre = nuevo_nombre
            plan.descripcion = nueva_descripcion
            plan.precio = nuevo_precio
            session.commit()

    @classmethod
    def eliminar(cls, id):
        plan = session.query(cls).filter_by(id=id).first()
        if plan:
            session.delete(plan)
            session.commit()

    @classmethod
    def listar(cls):
        planes = session.query(cls).all()
        return [plan.to_dict() for plan in planes]

class Descuento(Base):
    __tablename__ = 'descuento'

    id = Column(Integer, primary_key=True, autoincrement=True)
    plan = Column(Integer, ForeignKey('PlanHosting.id'), nullable=False)
    descuento = Column(DECIMAL(2, 2), nullable=False)
    creacion = Column(TIMESTAMP, default='CURRENT_TIMESTAMP')
    duracion_dias = Column(Integer, nullable=False)
    activo = Column(Boolean, default=True)

    plan_hosting = relationship("PlanHosting", back_populates="descuentos")

    def to_dict(self):
        return {
            "id": self.id,
            "plan": self.plan,
            "descuento": float(self.descuento),
            "creacion": self.creacion,
            "duracion_dias": self.duracion_dias,
            "activo": self.activo,
        }

    @classmethod
    def crear(cls, plan, descuento, duracion_dias, activo=True):
        nuevo_descuento = cls(plan=plan, descuento=descuento, duracion_dias=duracion_dias, activo=activo, creacion=datetime.utcnow())
        session.add(nuevo_descuento)
        session.commit()
        return nuevo_descuento

    @classmethod
    def leer_por_plan(cls, plan):
        descuento = session.query(cls).filter(
            cls.plan == plan,
            func.DATE_ADD(cls.creacion, text(f"INTERVAL {cls.duracion_dias} DAY")) >= datetime.utcnow()
        ).first()
        if descuento:
            return descuento.to_dict()
        return None

    @classmethod
    def modificar(cls, id, nuevo_descuento, nueva_duracion_dias, activo=True):
        descuento = session.query(cls).filter_by(id=id).first()
        if descuento:
            descuento.descuento = nuevo_descuento
            descuento.duracion_dias = nueva_duracion_dias
            descuento.activo = activo
            session.commit()

    @classmethod
    def eliminar(cls, id):
        descuento = session.query(cls).filter_by(id=id).first()
        if descuento:
            session.delete(descuento)
            session.commit()

class Cliente(Base):
    __tablename__ = 'Cliente'

    id = Column(Integer, primary_key=True, autoincrement=True)
    nombre = Column(String(100), nullable=False)
    link = Column(Text, nullable=False)
    logo = Column(Text, nullable=False)

    def to_dict(self):
        return {
            "id": self.id,
            "nombre": self.nombre,
            "link": self.link,
            "logo": self.logo,
        }
    
    @classmethod
    def crear(cls, nombre, link, logo):
        nuevo_cliente = cls(nombre=nombre, link=link, logo=logo)
        session.add(nuevo_cliente)
        session.commit()
        return nuevo_cliente

    @classmethod
    def leer_por_id(cls, id):
        cliente = session.query(cls).filter_by(id=id).first()
        if cliente:
            return cliente.to_dict()
        return None

    @classmethod
    def modificar(cls, id, nuevo_nombre, nuevo_link, nuevo_logo):
        cliente = session.query(cls).filter_by(id=id).first()
        if cliente:
            cliente.nombre = nuevo_nombre
            cliente.link = nuevo_link
            cliente.logo = nuevo_logo
            session.commit()

    @classmethod
    def eliminar(cls, id):
        cliente = session.query(cls).filter_by(id=id).first()
        if cliente:
            session.delete(cliente)
            session.commit()

    @classmethod
    def listar(cls):
        clientes = session.query(cls).all()
        return [cliente.to_dict() for cliente in clientes]

class ContratoHosting(Base):
    __tablename__ = 'ContratoHosting'

    id = Column(Integer, primary_key=True, autoincrement=True)
    correo_contacto = Column(String(100), nullable=False)
    plan_id = Column(Integer, ForeignKey('PlanHosting.id'))
    fecha_inicio = Column(Date, nullable=False)
    fecha_fin = Column(Date, nullable=False)

    plan_hosting = relationship("PlanHosting")

    def to_dict(self):
        return {
            "id": self.id,
            "correo_contacto": self.correo_contacto,
            "plan_id": self.plan_id,
            "fecha_inicio": self.fecha_inicio,
            "fecha_fin": self.fecha_fin,
        }

    @classmethod
    def crear(cls, correo_contacto, plan_id, fecha_inicio, fecha_fin):
        nuevo_contrato = cls(correo_contacto=correo_contacto, plan_id=plan_id, fecha_inicio=fecha_inicio, fecha_fin=fecha_fin)
        session.add(nuevo_contrato)
        session.commit()
        return nuevo_contrato

    @classmethod
    def leer_por_id(cls, id):
        contrato = session.query(cls).filter_by(id=id).first()
        if contrato:
            return contrato.to_dict()
        return None

    @classmethod
    def modificar(cls, id, nuevo_correo_contacto, nuevo_plan_id, nueva_fecha_inicio, nueva_fecha_fin):
        contrato = session.query(cls).filter_by(id=id).first()
        if contrato:
            contrato.correo_contacto = nuevo_correo_contacto
            contrato.plan_id = nuevo_plan_id
            contrato.fecha_inicio = nueva_fecha_inicio
            contrato.fecha_fin = nueva_fecha_fin
            session.commit()

    @classmethod
    def eliminar(cls, id):
        contrato = session.query(cls).filter_by(id=id).first()
        if contrato:
            session.delete(contrato)
            session.commit()

    @classmethod
    def listar(cls):
        contratos = session.query(cls).all()
        return [contrato.to_dict() for contrato in contratos]

    @classmethod
    def listar_por_faltan_10_dias(cls):
        fecha_limite = date.today() + timedelta(days=10)
        contratos = session.query(cls).filter(cls.fecha_fin <= fecha_limite).all()
        return [contrato.to_dict() for contrato in contratos]

class Comentario(Base):
    __tablename__ = 'Comentario'

    id = Column(Integer, primary_key=True, autoincrement=True)
    nombre = Column(String(100), nullable=True)
    correo = Column(String(100), nullable=True)
    mensaje = Column(Text, nullable=False)
    fecha_envio = Column(TIMESTAMP, default='CURRENT_TIMESTAMP')

    def to_dict(self):
        return {
            "id": self.id,
            "nombre": self.nombre,
            "correo": self.correo,
            "mensaje": self.mensaje,
            "fecha_envio": self.fecha_envio,
        }

    @classmethod
    def crear(cls, nombre, correo, mensaje):
        nuevo_comentario = cls(nombre=nombre, correo=correo, mensaje=mensaje, fecha_envio=datetime.utcnow())
        session.add(nuevo_comentario)
        session.commit()
        return nuevo_comentario

    @classmethod
    def leer_por_id(cls, id):
        comentario = session.query(cls).filter_by(id=id).first()
        if comentario:
            return comentario.to_dict()
        return None

    @classmethod
    def modificar(cls, id, nuevo_nombre, nuevo_correo, nuevo_mensaje):
        comentario = session.query(cls).filter_by(id=id).first()
        if comentario:
            comentario.nombre = nuevo_nombre
            comentario.correo = nuevo_correo
            comentario.mensaje = nuevo_mensaje
            session.commit()

    @classmethod
    def eliminar(cls, id):
        comentario = session.query(cls).filter_by(id=id).first()
        if comentario:
            session.delete(comentario)
            session.commit()

    @classmethod
    def cantidad(cls):
        return session.query(cls).count()

    @classmethod
    def listar(cls, offset, limit):
        comentarios = session.query(cls).offset(offset).limit(limit).all()
        return [comentario.to_dict() for comentario in comentarios]

Base.metadata.create_all(engine)