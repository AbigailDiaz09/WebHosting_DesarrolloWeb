from hosting_bd import Administrador, PlanHosting, Descuento, Cliente, ContratoHosting, Comentario

Administrador.crear('admin', 'contraseña')


plan = PlanHosting.crear('STARTER', '¡Todo lo que necesitas para comenzar!\n  ✓Espacio Web : 10G\n  ✓Registro de dominio\n  ✓Configuración Instantanea\n  ✓Transferencia Ilimitada', 500)
Descuento.crear(plan.id, 0.5, 1)

plan = PlanHosting.crear('BASICO', '¡La mejor solución para grandes proyecto!\n  ✓Espacio Web : 100G\n  ✓Incluye 1 dominio gratis\n  ✓Configuración Instantanea\n  ✓Transferencia Ilimitada\n  ✓Más de 140 Apps\n  ✓SiteBuilder co plantillas', 955)
Descuento.crear(plan.id, 0.6, 30)

plan = PlanHosting.crear('NO LIMITE', '¡Máximo rendimiento para proyectos \ninteractivos y con contenidos dinámicos!\n  ✓Espacio Web : Ilimitado\n  ✓Incluye 1 dominio gratis\n  ✓Configuración Instantanea\n  ✓Transferencia Ilimitada\n  ✓Más de 140 Apps\n  ✓SiteBuilder con plantillas\n  ✓Bases De Datos MySQL : Ilimitadas\n  ✓Cuentas de correo : Ilimitadas', 1548)
Descuento.crear(plan.id, 0.6, 30)

Cliente.crear('Facebook', 'www.facebook.com', 'facebook.png')
Cliente.crear('Wikipedia', 'es.wikipedia.org', 'wikipedia.png')
Cliente.crear('UAdeC', 'www.uadec.mx', 'uadec.png')